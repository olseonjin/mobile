package com.example.option;


import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    View view1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        view1= findViewById(R.id.layout);

        @Override
        public boolean onCreateOptionsMenu(Menu menu) {
            getMenuInflater().inflate(R.menu.mymenu, menu);
            return true;
        }
        @Override
                public boollean onOptionsItemSelected(MenuItem item) {
            int id = item.getItemId();
            if( id == R.id.blue ) {
                view1.setBackgroundColor(color.Blue);
                return true;
            }
            else if( id == R.id.green ) {
                view1.setBackgroundColor(color.GREEN);
                return true;
            }
            else if( id == R.id.red ) {
                view1.setBackgroundColor(color.RED);
                return true;
            }
            return super.onOptionItemSelected(item);
    }
}
